<!--
function frame()
{
	document.write( '<STYLE type="text/css"><!--BODY{margin-left : 150px;}--></STYLE>' );
	document.write( '<DIV style="top : 10px;left : 0px; position : absolute; z-index : 1; " id="Layer1">' );
	document.write( '<A href="//www.bigflower.co.jp/"><IMG src="//www.bigflower.co.jp/fram1.gif" border="0"></A></DIV>' );
	document.write( '<DIV style="top : 60px;left : 10px; position : absolute;z-index : 2;" id="Layer2">' );
	document.write( '<A href="//www.bigflower.co.jp/"><IMG src="//www.bigflower.co.jp/fram2.gif" border="0"></A></DIV>' );
	document.write( '<DIV style="top : 100px;left : 0px; position : absolute; z-index : 3;" id="Layer3"><DIV><TABLE border="0">' );
	document.write( '<TBODY><TR><TD width="129" bgcolor="#fef9de" height="175" align="center" valign="top"><B><FONT size="-1" color="#ff6633">����s�v�E�M�t�g��</FONT></B><BR>' );
	document.write( '<A href="//www.bigflower.jp" target="_blank"><IMG src="//www.bigflower.co.jp/fram3.gif" width="117" height="30" border="0"></A><BR>' );
	document.write( '<A href="//www.bigflower.co.jp/v/v-ez.htm"><IMG src="//www.bigflower.co.jp/fram4.gif" border="0"></A><BR>' );
    document.write( '<A href="//www.bigflower.co.jp/H/"><IMG src="//www.bigflower.co.jp/fram5.gif" border="0"></A><BR><BR>' );
    document.write( '<FONT color="#ff6633"><B><FONT size="-1">����s�v�E�M�t�g�s��</FONT></B></FONT><BR>' );
    document.write( '<A href="//www.bigflower.co.jp/sizai/"><IMG src="//www.bigflower.co.jp/fram6.gif" border="0"><BR></A></TD>' );
    document.write( '</TR></TBODY></TABLE></DIV></DIV>' );
    document.write( '<DIV style="top : 280px;left : 0px; position : absolute; z-index : 4; " id="Layer4"><DIV>' );
	document.write( '<TABLE border="0"><TBODY><TR>' );
	document.write( '<TD width="129" height="70" bgcolor="#fef9de" valign="top" align="center"><B><FONT size="-1" color="#669900">�v����E�M�t�g�s��</FONT></B><BR>' );
	document.write( '<B><FONT color="#669900" size="-1">����̔��E�ň��l</FONT></B><BR>' );
	document.write( '<B><FONT size="-1" color="#669900"><A href="//www.bigflower.co.jp/chuui.htm"><IMG src="//www.bigflower.co.jp/fram7.gif" border="0"></A><BR>' );
    document.write( '</FONT></B></TD></TR></TBODY></TABLE></DIV></DIV>' );
	document.write( '<DIV style="top : 370px;left : 10px; position : absolute; z-index : 5;" id="Layer5"><A href="//www.bigflower.co.jp/mac.htm" target="_blank"><IMG src="//www.bigflower.co.jp/mac.gif" border="0"></A></DIV>' );
}
//-->
