<!--
kaisen=29;
stypeT[ 29 ]= 4 ;
kaisenT[ 29 ]= 29 ;
knenT[ 29 ]= 0 ;
ktukiT[ 29 ]= 0 ;
khiT[ 29 ]=14;
snenT[ 29 ]= 0 ;
stukiT[ 29 ]= 0 ;
shiT[ 29 ]= 0 ;
sjiT[ 29 ]= 0 ;
shunT[ 29 ]= 0 ;
syoubiT[ 29 ]="";
osusumeT[ 29 ]= 0 ;
hanbai1T[ 29 ]="";
hanbai2T[ 29 ]="";
hanbai3T[ 29 ]="";
headerT[ 29 ]="";
// -->
