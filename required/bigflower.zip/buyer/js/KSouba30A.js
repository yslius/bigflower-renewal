<!--
kaisen=30;
stypeT[ 30 ]= 4 ;
kaisenT[ 30 ]= 30 ;
knenT[ 30 ]= 0 ;
ktukiT[ 30 ]= 0 ;
khiT[ 30 ]=14;
snenT[ 30 ]= 0 ;
stukiT[ 30 ]= 0 ;
shiT[ 30 ]= 0 ;
sjiT[ 30 ]= 0 ;
shunT[ 30 ]= 0 ;
syoubiT[ 30 ]="";
osusumeT[ 30 ]= 0 ;
hanbai1T[ 30 ]="";
hanbai2T[ 30 ]="";
hanbai3T[ 30 ]="";
headerT[ 30 ]="";
// -->
