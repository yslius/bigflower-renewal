<!--
kaisen=27;
stypeT[ 27 ]= 4 ;
kaisenT[ 27 ]= 27 ;
knenT[ 27 ]= 0 ;
ktukiT[ 27 ]= 0 ;
khiT[ 27 ]=14;
snenT[ 27 ]= 0 ;
stukiT[ 27 ]= 0 ;
shiT[ 27 ]= 0 ;
sjiT[ 27 ]= 0 ;
shunT[ 27 ]= 0 ;
syoubiT[ 27 ]="";
osusumeT[ 27 ]= 0 ;
hanbai1T[ 27 ]="";
hanbai2T[ 27 ]="";
hanbai3T[ 27 ]="";
headerT[ 27 ]="";
// -->
