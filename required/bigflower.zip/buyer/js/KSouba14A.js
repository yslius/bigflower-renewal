<!--
kaisen=14;
stypeT[ 14 ]= 4 ;
kaisenT[ 14 ]= 14 ;
knenT[ 14 ]= 0 ;
ktukiT[ 14 ]= 0 ;
khiT[ 14 ]=14;
snenT[ 14 ]= 0 ;
stukiT[ 14 ]= 0 ;
shiT[ 14 ]= 0 ;
sjiT[ 14 ]= 0 ;
shunT[ 14 ]= 0 ;
syoubiT[ 14 ]="";
osusumeT[ 14 ]= 0 ;
hanbai1T[ 14 ]="";
hanbai2T[ 14 ]="";
hanbai3T[ 14 ]="";
headerT[ 14 ]="";
// -->
